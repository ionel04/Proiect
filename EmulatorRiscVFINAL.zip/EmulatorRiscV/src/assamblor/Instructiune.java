package assamblor;
import java.util.List;
public class Instructiune {
    private int[] rez;

    Instructiune(LinieCurata linieCurata, int curent , List<LinieCurata> program ) throws UnknownInstruction,  LabelNotExisting {
        rez = new int[32];
        String[] tokens = linieCurata.returnLiniaCurata();

        switch (tokens[1]) {
            case "ADD":
                setOpcode("0110011");
                setFunct3("000");
                setFunct7("0000000");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "OR":
                setOpcode("0110011");
                setFunct3("110");
                setFunct7("0000000");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "AND":
                setOpcode("0110011");
                setFunct3("111");
                setFunct7("0000000");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "ADDI":
                setOpcode("0010011");
                setFunct3("000");
                setRegistersImmediate(tokens[2], tokens[3], tokens[4]);
                break;

            case "SUBI": // MAI E DE LUCRAT AICI
                setOpcode("0010011");
                setFunct3("000");
                setRegistersImmediateSubi(tokens[2], tokens[3], tokens[4]);

                break;

            case "SUB":
                setOpcode("0110011");
                setFunct3("000");
                setFunct7("0100000");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "MUL":
                setOpcode("0110011");
                setFunct3("000");
                setFunct7("0000001");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "DIV":
                setOpcode("0110011");
                setFunct3("100");
                setFunct7("0000001");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "REM":
                setOpcode("0110011");
                setFunct3("110");
                setFunct7("0000001");
                setRegisters(tokens[2], tokens[3], tokens[4]);
                break;

            case "LW": // load din memorie in registru
                setOpcode("0000011");
                setFunct3("010");
                setRegDest(tokens[2]);
                int aux = Integer.parseInt(tokens[3]); // valoarea de offset, formula pentru adresa = imm + valoare reg baza
                setImmediateBit(aux,20,12);
                setRegBase(tokens[4]);
                break;

            case "SW": // store din registru in memorie
                setOpcode("0100011");              // Correct: opcode for store instructions (SW)
                setFunct3("010");                  // Correct: funct3 for SW is 010
                //token[3] val imediata
                setImmediateStore(tokens[3]);
                setRegBase(tokens[4]);
                setRs2(tokens[2]);
                break;

            case "POP":
                setOpcode("0000011");
                setRegDest(tokens[2]);
                setFunct3("010");
                setRegBase("R8");    //daca baza este 8 va trebui sa incremantam sau sa scadem valoare din R8
                String immediatePOP = "111111111100";   // 4, negativ in complement de 2
                setImmediate(immediatePOP);
                break;

            case "PSH":
                setOpcode("0100011");
                setFunct3("010");
                setRegBase("R8");
                setRs2(tokens[2]);
                String immediatePSH = "111111111100";
                String immHighPSH = immediatePSH.substring(0, 5);
                //System.out.println(immHighPSH);
                String immLowPSH = immediatePSH.substring(5, 12);
                //System.out.println(immLowPSH);

                for(int i=7; i<=11; i++) {
                    rez[i] = immHighPSH.charAt(i - 7) - '0';
                }

                for(int i=25; i<32; i++) {
                    rez[i] = immLowPSH.charAt(i - 25) - '0';
                }
                break;


            case "JAL":
                setOpcode("1101111");
                setRegisterBits(11, tokens[2]);
                int offset = getOffset(tokens[3], curent, program);
                //setOffsetJAL(offset);
                setImmediateSignedBit(offset,20,11);
                break;
            case "JALR":
                setOpcode("1100111");
                setRegisterBits(11, tokens[2]);
                setRegisterBits(19, tokens[3]);
                setFunct3("000");
                setImmediateSignedBit(Integer.parseInt(tokens[4]),20,11);
                break;

            case "BEQ":
                setOpcode("1100011");
                setFunct3("000");
                setRegisterBits(19, tokens[2]);
                setRegisterBits(24,tokens[3]);
                offset = getOffset(tokens[4], curent, program);
                setImmediateBranch(offset);
                break;
            case "BNE":
                setOpcode("1100011");
                setFunct3("001");
                setRegisterBits(19, tokens[2]);
                setRegisterBits(24,tokens[3]);
                offset = getOffset(tokens[4], curent, program);
                setImmediateBranch(offset);
                break;
            case "BLT":
                setOpcode("1100011");
                setFunct3("100");
                setRegisterBits(19, tokens[2]);
                setRegisterBits(24,tokens[3]);
                offset = getOffset(tokens[4], curent, program);
                setImmediateBranch(offset);
                break;
            case "BGE":
                setOpcode("1100011");
                setFunct3("101");
                setRegisterBits(19, tokens[2]);
                setRegisterBits(24,tokens[3]);
                offset = getOffset(tokens[4], curent, program);
                setImmediateBranch(offset);
                break;
            case "BLTU":
                setOpcode("1100011");
                setFunct3("110");
                setRegisterBits(19, tokens[2]);
                setRegisterBits(24,tokens[3]);
                offset = getOffset(tokens[4], curent, program);
                setImmediateBranch(offset);
                break;
            case "BGEU":
                setOpcode("1100011");
                setFunct3("111");
                setRegisterBits(19, tokens[2]);
                setRegisterBits(24,tokens[3]);
                offset = getOffset(tokens[4], curent, program);
                setImmediateBranch(offset);
                break;
            case "HLT":

                break;


            default:

                throw new UnknownInstruction("Instructiune necunoscuta: ");
        }
    }

    private void setOpcode(String opcode) {
        for (int i = 0; i < 7; i++) {
            rez[6 - i] = opcode.charAt(i) - '0';
        }
    }

    private int getOffset(String destLabel, int poz_curenta, List<LinieCurata> program ) throws LabelNotExisting
    {
        int i=0;
        poz_curenta = poz_curenta * 4;
        for(LinieCurata line : program)
        {
            if(destLabel.equals(line.returnLiniaCurata()[0])==true)
            {
                return i-poz_curenta;
            }
            i=i+4;
        }
        throw new LabelNotExisting("nu exista destinatia dorita");
    }

    private void setFunct3(String funct3) {
        for (int i = 0; i < 3; i++) {
            rez[14 - i] = funct3.charAt(i) - '0';
        }
    }

    private void setFunct7(String funct7) {
        for (int i = 0; i < 7; i++) {
            rez[31 - i] = funct7.charAt(i) - '0';
        }
    }

    private void setRegisters(String rd, String rs1, String rs2) {
        setRegisterBits(11, rd);
        setRegisterBits(19, rs1);
        setRegisterBits(24, rs2);
    }

    private void setRs2(String rs2) {
        setRegisterBits(24, rs2);
    }

    private void setRegDest(String rd) {
        setRegisterBits(11, rd);
    }

    private void setRegBase(String rd) {

        setRegisterBits(19, rd);
    }

    private void setRegistersImmediate(String rd, String rs1, String imm) {
        setRegisterBits(11, rd);
        setRegisterBits(19, rs1);
        int val = Integer.parseInt(imm);
        setImmediateSignedBit(val,20,11);
        //setImmediate(StringToBin12Bits(imm));
    }

    private void setRegistersImmediateSubi(String rd, String rs1, String imm) {
        setRegisterBits(11, rd);
        setRegisterBits(19, rs1);
        setImmediate(StringToBin12BitsNegative(imm));
    }



    private void setRegisterBits(int startIndex, String reg) {
        try {
            int regNum = Integer.parseInt(reg.substring(1));
            if (regNum > 8)
                throw new Exception();
            for (int i = 0; i < 5; i++) {
                rez[startIndex -5 + 1 +i] = (regNum >> i) & 1;
            }
        } catch (Exception e) {
            System.out.println("invalid format for arguments");
        }
    }

    private String StringToBin12BitsNegative(String nr)
    {
        int number = Integer.parseInt(nr);

        if(number > 0)
        {
            number = number * -1;
            number = (1 << 12) + number;
        }

        else
        {
            number = number * -1;
        }
        String bin = Integer.toBinaryString(number);
        return String.format("%12s", bin).replace(' ', '0');
    }
    private String StringToBin12Bits(String nr) {
        int number = Integer.parseInt(nr);
        if (number < 0) {
            number = (1 << 12) + number; // (prin incantatia asta, optinem complementul de 2, aparent adaugad 4096, la numarul nostru negativ, nu pusca codul instructiuni, si obtine numarul in complement de 2, GG MAH, GG)
        }
        String bin = Integer.toBinaryString(number);
        return String.format("%12s", bin).replace(' ', '0');
    }

    private void setImmediate(String bin) {
        for (int i = 0; i < 12; i++) {
            rez[20 + i] = bin.charAt(11 - i) - '0'; // Map immediate to bits 31:20
        }
    }

    private void setImmediateStore(String imm)
    {
        int val = Integer.parseInt(imm);
        // 7 11 - 0 4
        //25 31 - 5 11
        for(int i=7;i<=11;i++)
            rez[i] = (val>>(i-7)) & 1;
        for(int i=25;i<=31;i++)
            rez[i] = (val >> (i-20)) & 1;
    }

    private void setImmediateBit(int val, int start, int numberOFBits)
    {
        int stop = start + numberOFBits - 1;
        for(int i=start; i<=stop; i++)
        {
            rez[i]= (val>>(i-start)) & 1;
        }
    }
    private void setImmediateSignedBit(int val, int start, int numberOFBits)
    {
        int stop = start + numberOFBits -1;
        if(val>=0)
            rez[stop]=0;
        else
        {
            rez[stop]=1;
            val =val * (-1);
        }
        int j=0;
        for(int i=start; i<stop; i++)
        {
            rez[i]= (val>>j) & 1;
            j++;
        }
    }

    private void setOffsetJAL(int offset)
    {
        if(offset>=0)
            rez[31] = 0;
        else
        {
            rez[31] = 1;
            offset = offset * (-1);
        }
        for(int i=19; i >= 12 ; i--)
        {
            rez[i] = (offset>>(i-2)) & 1;
        }
        rez[20] = (offset>>9) & 1;
        for(int i=30; i>21; i--)
        {
            rez[i] = (offset>>(i-20-2)) & 1;
        }
        rez[21] = 0;
    }
    private void  setImmediateBranch(int val)
    {
        setImmediateSignedBit(val, 25, 6);

    }
    public int[] returnRez() {
        return rez;
    }
}
