package assamblor;

public class Cpu {

    public int pc = 0;
    public int[] reg = new int[8];
    public Memory InstructionMemory;
    public Memory DataMemory;

    public Cpu(Memory InstructionMemory, Memory DataMemory)
    {
        this.InstructionMemory = InstructionMemory;
        this.DataMemory = DataMemory;
        reg[2] = DataMemory.getMemorySize() - 1;
    }

    public void executeInstruction()throws ExecutionFinish
    {
        if(pc%4 != 0) throw new ExecutionFinish("adresa pt instructiune invalida");
        int opcode = 0b1111111;
        int operatieCurenta = InstructionMemory.getWord(pc);
        opcode = opcode & operatieCurenta ;

        switch (opcode) {
            case 0b0000000: // Halt instruction
                System.out.println("Halt instruction encountered. Stopping execution.");
                throw new ExecutionFinish("S-a terminat executia programului"); // Terminate program

            case 0b0110011: // R-type instruction (e.g., ADD, SUB)
                executeRType(operatieCurenta);
                break;

            case 0b0010011: // I-type instruction (e.g., ADDI, ORI)
                executeIType(operatieCurenta);
                break;

            case 0b0000011: // Load instruction
                executeLoad(operatieCurenta);
                break;
            //S Type
            case 0b0100011: // Store instruction
                executeStore(operatieCurenta);
                break;
            case 0b1101111: //JAL
                executeJAL(operatieCurenta);
                break;
            case 0b1100111: // JALR
                executeJALR(operatieCurenta);
                break;
            //B type
            case 0b1100011: // BEQ / BNE / BLT / BGE / BLTU / BGEU
                executeBType(operatieCurenta);
                break;
            default: // Unknown opcode
                System.err.println("Unknown opcode: " + Integer.toBinaryString(opcode));
                break;
        }
    }
    private void executeRType(int operatieCurenta)
    {
        int funct3 = (operatieCurenta>>12) & (0b111);
        int funct7 = (operatieCurenta>>25) & (0b1111111);
        int rs1 = (operatieCurenta>>15) & (0b11111);
        int rs2 = (operatieCurenta>>20) & (0b11111);
        int rd = (operatieCurenta>>7) & (0b11111);
        switch(funct3){
            case 0b000: // ADD // SUB // MUL
                switch(funct7){
                    case 0b0000000: // ADD
                        reg[rd] = reg[rs1] + reg[rs2];
                        break;
                    case 0b0100000: // SUB
                        reg[rd] = reg[rs1] - reg[rs2];
                        break;
                    case 0b0000001: // MUL
                        reg[rd] = reg[rs1] * reg[rs2];
                        break;
                }
                break;
            case 0b100: // DIV
                switch(funct7){
                    case 0b0000001:
                        if (reg[rs2] == 0){
                            reg[rd] = 0;
                        }else{
                            reg[rd] = reg[rs1] / reg[rs2];
                        }
                        break;
                }
                break;
            case 0b111: // AND
                switch(funct7){
                    case 0b0000000:
                        reg[rd] = reg[rs1] & reg[rs2];
                        break;
                }
                break;
            case 0b110: //  OR  // REM
                switch(funct7){
                    case 0b0000000: //  OR
                        reg[rd] = reg[rs1] | reg[rs2];
                        break;
                    case 0b0000001: //  REM
                        if(reg[rs2] == 0){
                            reg[rd] = 0;
                        }else{
                            reg[rd] = reg[rs1] % reg[rs2];
                        }
                        break;
                }
                break;
        }

        pc = pc+4;

    }
    private void executeIType(int operatieCurenta)
    {
        int funct3 = (operatieCurenta>>12) & (0b111);
        int rs1 = (operatieCurenta>>15) & (0b11111);
        int rd = (operatieCurenta>>7) & (0b11111);
        int imm = (operatieCurenta>>20) & (0b1111111111);
        if(((operatieCurenta>>30) & (0b1)) == 1) {
            imm = imm * (-1);
        }
        if(funct3 == 0b000)
        {
            reg[rd] = reg[rs1] + imm;
        }
        pc = pc + 4;
    }
    private void executeBType(int operatieCurenta)
    {
        int rs1 = (operatieCurenta>>15) & (0b11111);
        int rs2 = (operatieCurenta>>20) & (0b11111);
        int funct3 = (operatieCurenta>>12) & (0b111);
        int immediate = (operatieCurenta>>25) & (0b11111);
        if(((operatieCurenta>>30) & (0b1)) == 1)
        {
            immediate = immediate* (-1);
        }
        switch(funct3){
            case 0b000: // BEQ
                pc += (reg[rs1] == reg[rs2]) ? immediate : 4;
                break;
            case 0b001: // BNE
                pc += (reg[rs1] != reg[rs2]) ? immediate : 4;
                break;
            case 0b100: // BLT
                pc += (reg[rs1] < reg[rs2]) ? immediate : 4;
                break;
            case 0b101: // BGE
                pc += (reg[rs1] >= reg[rs2]) ? immediate : 4;
                break;
            case 0b110: //BLTU
                pc += (Integer.toUnsignedLong(reg[rs1]) < Integer.toUnsignedLong(reg[rs2])) ? immediate : 1;
                break;
            case 0b111: //BLGEU
                pc += (Integer.toUnsignedLong(reg[rs1]) >= Integer.toUnsignedLong(reg[rs2])) ? immediate : 1;
                break;
        }
    }
    private void executeLoad(int operatieCurenta)
    {

        int funct3 = (operatieCurenta>>12) & (0b111);
        int rs1 = (operatieCurenta>>15) & (0b11111);
        int rd = (operatieCurenta>>7) & (0b11111);
        int imm = (operatieCurenta>>20) & (0b111111111111);
        int adress = reg[rs1] + imm;
        int aux = DataMemory.getWord(adress);

        if(funct3 == 0b010)
        {
            reg[rd] = aux;
            pc += 4;
        }

    }
    private void executeStore(int operatieCurenta)
    {
        int funct3 = (operatieCurenta>>12) & (0b111);
        int rs1 = (operatieCurenta>>15) & (0b11111);
        int imm = (operatieCurenta>>7) & (0b11111);
        int rs2 = (operatieCurenta>>20) & (0b11111);
        imm = imm + ((operatieCurenta >> 25) & (0b1111111));
        int adress = reg[rs1] + imm;

        if(funct3 == 0b010)
        {
            DataMemory.storeWord(adress, reg[rs2]);
            pc += 4;
        }
    }
    private void executeJAL(int operatieCurenta)
    {
        int rd = (operatieCurenta>>7) & (0b11111);
        int imm = (operatieCurenta>>20) & (0b111111111);
        if(((operatieCurenta>>30) & (0b1)) == 1)
        {
            imm = imm*(-1);
        }
        reg[rd] = (pc+4); // Store address of next instruction in bytes
        pc += imm;
    }
    private void executeJALR(int operatieCurenta)
    {
        int rd = (operatieCurenta>>7) & (0b11111);
        int rs1 = (operatieCurenta>>15) & (0b11111);
        int imm = (operatieCurenta>>20) & (0b1111111111);
        if(((operatieCurenta>>30) & (0b1)) == 1)
        {
            imm = imm* (-1);
        }
        reg[rd] = (pc+4);
        pc = (reg[rs1] + imm);

    }
}
