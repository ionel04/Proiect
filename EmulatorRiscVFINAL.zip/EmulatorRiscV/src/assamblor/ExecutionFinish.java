package assamblor;

public class ExecutionFinish extends Exception
{
    public ExecutionFinish(String mesage)
    {
        super(mesage);
    }
}