package assamblor;

public class LabelNotExisting extends Exception {
    public LabelNotExisting(String msg) {
        super(msg);
    }
}