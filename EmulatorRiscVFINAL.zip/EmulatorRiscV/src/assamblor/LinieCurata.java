package assamblor;

public class LinieCurata {
    private String eticheta;
    private String instructiune;
    private String input;
    private String[] tokens; // Vectorul de stringuri in care vom salva fiecare parte a instructiunii.

    public int isInstruction(String aux){
        int instr = 0;
        // Verificam daca instructiunea este valida
        switch (aux){
            case "ADD":    // OK
                instr = 1;
                break;

            case "ADDI":   //OK
                instr = 1;
                break;

            case "AND":    //OK
                instr = 1;
                break;

            case "OR":     //OK
                instr = 1;
                break;

            case "SUB":     //OK
                instr = 1;
                break;

            case "SUBI":    //OK
                instr = 1;
                break;

            case "MUL":     //OK
                instr = 1;
                break;

            case "LW":      //OK
                instr = 1;
                break;

            case "DIV":     //OK
                instr = 1;
                break;

            case "SW":      //OK
                instr = 1;
                break;

            case "MOV":     // ne trebuie neaparat ? in manual de risc scrie ca in spate sunt implementate cu ADDI
                instr = 1;
                break;

            case "JAL":
                instr = 1;
                break;

            case "JALR":
                instr = 1;
                break;

            case "BEQ":
                instr = 1;
                break;

            case "BNE":
                instr = 1;
                break;

            case "BLT":
                instr = 1;
                break;

            // case "BGT":
            //     instr = 1;
            //     break;

            case "BLTU":
                instr = 1;
                break;

            case "BGEU":
                instr = 1;
                break;

            case "BGE":
                instr = 1;
                break;

            case "HLT":     // OK
                instr = 1;
                break;

            case "REM":     //OK
                instr = 1;
                break;

            case "POP":    //ok
                instr = 1;
                break;

            case "PSH":
                instr = 1;
                break;
            default:
                break;
        }
        return instr;
    }

    String removeConsecutiveSpaces(String input) {
        if (input == null) {
            return null;
        }
        return input.replaceAll("\\s+", " ").trim();
    }

    LinieCurata(String input) {
        this.input = input;
        this.input = removeConsecutiveSpaces(this.input); // Eliminam spatiile consecutive
        this.input = this.input.toUpperCase(); // Transformam in litere mari
        String delims = "[ ,()]"; // Separator: spatiu, virgula, paranteze
        this.tokens = this.input.split(delims);

        if (isInstruction(tokens[0]) == 1) {
            this.input = "- " + this.input;
            this.tokens = this.input.split(delims);
        }

        this.instructiune = tokens[1];
        this.eticheta = tokens[0];

        if (isInstruction(this.instructiune) == 0) {
            tokens[0] = "invalid ";
        }
    }

    public String[] returnLiniaCurata() {
        return this.tokens;
    }

    public String toString() {
        String rez = "";

        for (String i : tokens) {
            rez = rez + i;

        }
        return rez;
    }
}
