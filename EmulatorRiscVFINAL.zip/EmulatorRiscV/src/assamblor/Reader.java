package assamblor;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Reader {

    public static  Memory createInstructionMemory() {
        Memory instructionMemory = new Memory(1024);
        try {
            int indexAdresare = 0;
            File myObj = new File("src/in.txt");
            Scanner myReader = new Scanner(myObj);
            List<LinieCurata> Program = new ArrayList<>();
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                LinieCurata instructiune = new LinieCurata(data);
                Program.add(instructiune);
            }
            myReader.close();
            int curent=0;
            for (LinieCurata linie : Program) {
                System.out.println(linie);
                try {
                    if (linie.returnLiniaCurata()[0].equals("invalid")) {
                        throw new UnknownInstruction("Instructiune invalida: " + linie.returnLiniaCurata()[1]);
                    }
                } catch (UnknownInstruction e) {
                    System.out.println("Instructiune necunoscuta");
                }

                Instructiune instructiune = new Instructiune(linie, curent, Program);
                int[] rez = instructiune.returnRez();

                instructionMemory.storeInstruction(indexAdresare, rez);
                indexAdresare += 4;

                for (int i = 31; i >= 0; i--) {
                    System.out.print(rez[i]);
                }
                System.out.println("");
                curent++;


            }
            //byte [] memoriePentruAfisare = instructionMemory.getMemory();
            // for(int i=0; i<8; i++)
            // {
            //     System.out.println(memoriePentruAfisare[i]);
            //     String binaryString = String.format("%8s", Integer.toBinaryString(memoriePentruAfisare[i]& 0xFF)).replace(' ', '0');

            //     System.out.println(binaryString);
            // }



        } catch (FileNotFoundException e) {
            System.out.println("Eroare la citirea fisierului.");
            e.printStackTrace();
        } catch (UnknownInstruction e) {
            System.out.println("Instructiune necunoscuta");
            System.exit(1);
        } catch (LabelNotExisting e) {
            System.out.println("Nu exista labe-ul");
            System.exit(1);
        }
        return instructionMemory;
    }

}
// ADRESELE IN RISC V SUNT PE 5 BITI.
// adresa R0 este = 00000
// adresa R1 este = 00001
// adresa R2 este = 00010
// adresa R3 este = 00011
// adresa R4 este = 00100
// adresa R5 este = 00101
// adresa R6 este = 00110
// adresa R7 este = 00111

// adresa R8 este SP(stack pointer);