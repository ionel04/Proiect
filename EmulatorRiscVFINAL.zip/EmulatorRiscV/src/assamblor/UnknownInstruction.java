package assamblor;
public class UnknownInstruction extends Exception {
    public UnknownInstruction(String msg) {
        super(msg);
    }
}
