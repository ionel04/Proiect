import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import assamblor.*;

public class Main extends JFrame implements ActionListener {
    private JButton pcButton; // Buton pentru incrementarea valorii PC
    private JLabel label; // Eticheta pentru afisarea valorii curente a PC
    private JTextArea registerTextArea; // Zona text pentru afisarea registrelor
    private JTextArea instructionTextArea; // Zona text pentru afisarea memoriei de instructiuni
    private JTextArea dataTextArea; // Zona text pentru afisarea memoriei de date
    private Cpu core; // Instanta CPU pentru gestionarea operatiilor

    public Main() {

        Memory InstructionMemory = Reader.createInstructionMemory();
        Memory DataMemory = new Memory(400);
        core = new Cpu(InstructionMemory, DataMemory);

        // Executa instructiunea 0 inainte de a apasa butonul
        try {
            core.executeInstruction();
        } catch (ExecutionFinish ex) {
            JOptionPane.showMessageDialog(this, "Executia programului s-a terminat.", "Finalizat", JOptionPane.INFORMATION_MESSAGE);
        }

        // Setari initiale pentru JFrame
        setTitle("emulatorRiscV");
        setSize(1200, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Creare si configurare buton PC
        pcButton = new JButton("Increment PC");
        pcButton.setBounds(50, 50, 150, 30);
        pcButton.addActionListener(this); // Adaugare actiune pentru buton

        // Creare si configurare eticheta pentru PC
        label = new JLabel("PC: " + core.pc);
        label.setBounds(50, 100, 200, 30);

        // Creare JTextArea pentru registre si populare initiala
        registerTextArea = new JTextArea("REGISTRE:\n");
        registerTextArea.setEditable(false); // TextArea este doar pentru citire
        updateRegisters(); // Populare cu valori initiale
        JScrollPane registerScrollPane = new JScrollPane(registerTextArea);
        registerScrollPane.setBounds(250, 50, 200, 300);

        // Creare JTextArea pentru memoria de instructiuni si populare cu valori
        instructionTextArea = new JTextArea("INSTRUCTION MEMORY:\n");
        int aux = 0;
        instructionTextArea.setEditable(false);
        for (int i = 0; i < 400; i++) {
            try {
                if(aux == 3)
                {
                    instructionTextArea.append("Adr " + i + ": " + InstructionMemory.getByte(i) + " \n\n");
                    aux = 0;
                }
                else {
                    instructionTextArea.append("Adr " + i + ": " + InstructionMemory.getByte(i) + "   ");
                    aux = aux + 1;
                }
            } catch (IndexOutOfBoundsException e) {
                instructionTextArea.append("Adresa " + i + ": ERR (Out of Bounds)\n");
            }
        }
        JScrollPane instructionScrollPane = new JScrollPane(instructionTextArea);
        instructionScrollPane.setBounds(600, 50, 400, 300);

        // Creare JTextArea pentru memoria de date si populare initiala
        dataTextArea = new JTextArea("DATA MEMORY:\n");
        dataTextArea.setEditable(false);
        updateDataMemory(); // Populare cu valori initiale
        JScrollPane dataScrollPane = new JScrollPane(dataTextArea);
        dataScrollPane.setBounds(250, 400, 750, 300);

        // Adaugare componente in JFrame
        add(pcButton);
        add(label);
        add(registerScrollPane);
        add(instructionScrollPane);
        add(dataScrollPane);

        // Afisare fereastra
        setVisible(true);
    }

    public static void main(String[] args) {
        new Main(); // Creare instanta a clasei Main
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == pcButton) { // Verificare daca actiunea provine de la butonul PC
            try {
                core.executeInstruction(); // Executa instructiunea curenta
                label.setText("PC: " + core.pc); // Actualizare eticheta cu noua valoare a PC
                updateRegisters(); // Actualizare valori registre
                updateDataMemory(); // Actualizare valori memorie de date
            } catch (ExecutionFinish ex) {
                JOptionPane.showMessageDialog(this, "Executia programului s-a terminat.", "Finalizat", JOptionPane.INFORMATION_MESSAGE);
            } catch (IndexOutOfBoundsException ex) {
                JOptionPane.showMessageDialog(this, "Eroare: PC sau acces memoria a depasit limitele.", "Eroare", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Metoda pentru actualizarea registrelor
    private void updateRegisters() {
        registerTextArea.setText("REGISTRE:\n");
        for (int i=0; i<8; i++) {
            registerTextArea.append("R" + i +" = "+ core.reg[i] + "\n"); // Adaugare valori registre actualizate
        }
    }

    // Metoda pentru actualizarea memoriei de date
    private void updateDataMemory() {
        dataTextArea.setText("DATA MEMORY:\n");
        for (int i = 0; i < 400; i++) {
            try {
                dataTextArea.append("Adresa " + i + ": " + core.DataMemory.getByte(i) + "\n");
            } catch (IndexOutOfBoundsException e) {
                dataTextArea.append("Adresa " + i + ": ERR (Out of Bounds)\n");
            }
        }
    } 
    
}
